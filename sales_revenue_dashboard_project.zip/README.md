# Sales & Revenue Analysis Dashboard

A beginner-friendly dashboard project.

## Features
- Import CSV sales data
- Calculate Total Sales, Revenue and Profit
- Monthly revenue trends
- Top-performing products
- Regional analysis

## Run
```bash
pip install pandas plotly streamlit
streamlit run app.py
```
