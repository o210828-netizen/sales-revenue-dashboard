import pandas as pd
import streamlit as st

st.title("Sales & Revenue Analysis Dashboard")

df = pd.read_csv("sales_data.csv")

st.metric("Total Revenue", int(df["Revenue"].sum()))
st.metric("Total Profit", int(df["Profit"].sum()))

st.subheader("Revenue by Product")
st.bar_chart(df.groupby("Product")["Revenue"].sum())

st.subheader("Revenue by Region")
st.bar_chart(df.groupby("Region")["Revenue"].sum())
